import time
from dataclasses import dataclass
from typing import Optional
from rich.console import Console
from rich.table import Table

@dataclass
class Inventory:
    asv_mint: str
    sol_mint: str
    max_asv_position: int
    max_daily_sol_spend: float
    dca_asv_per_day: int
    console: Optional[Console] = None

    def __post_init__(self):
        self.asv_pos = 0
        self.sol_pos = 10.0
        self.daily_sol_spend = 0.0
        self.day_key = self._day_key(time.time())

    def _day_key(self, ts: float) -> str: return time.strftime("%Y-%m-%d", time.localtime(ts))
    def _roll_day(self):
        cur = self._day_key(time.time())
        if cur != self.day_key: self.day_key = cur; self.daily_sol_spend = 0.0

    def status_line(self, sol_ctx=None) -> str:
        self._roll_day()
        return (f"[paper-ledger] ASV:{self.asv_pos}  SOL:{self.sol_pos:.4f}  "
                f"daily_SOL_spend:{self.daily_sol_spend:.4f}/{self.max_daily_sol_spend:.4f}")

    def summary_table(self) -> Table:
        t = Table(title="Paper Ledger Summary"); t.add_column("Asset"); t.add_column("Balance")
        t.add_row("ASV", str(self.asv_pos)); t.add_row("SOL", f"{self.sol_pos:.6f}")
        t.add_row("Daily SOL Spend", f"{self.daily_sol_spend:.4f}/{self.max_daily_sol_spend:.4f}")
        return t

    def size_buy_asv(self, trade_asv_size: int, share: float) -> int:
        self._roll_day()
        target = int(trade_asv_size * share)
        if self.asv_pos + target > self.max_asv_position: target = max(0, self.max_asv_position - self.asv_pos)
        return max(0, target)

    def size_sell_asv(self, trade_asv_size: int, share: float) -> int:
        target = int(trade_asv_size * share)
        if target > int(self.asv_pos * 0.25): target = int(self.asv_pos * 0.25)
        return max(0, min(target, self.asv_pos))

    def on_buy_filled(self, asv_units: int, sol_spent: float):
        self.asv_pos += asv_units; self.sol_pos -= sol_spent; self.daily_sol_spend += sol_spent
        if self.console: self.console.log(f"[green]BUY filled[/green] +{asv_units} ASV  -{sol_spent:.6f} SOL")

    def on_sell_filled(self, asv_units: int, sol_received: float):
        self.asv_pos -= asv_units; self.sol_pos += sol_received
        if self.console: self.console.log(f"[yellow]SELL filled[/yellow] -{asv_units} ASV  +{sol_received:.6f} SOL")
