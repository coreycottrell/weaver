import time
from dataclasses import dataclass
from typing import Optional
from rich.console import Console

@dataclass
class TradeSignal:
    side: str
    ref_trade_size_asv: int

@dataclass
class AccumulatorByFlow:
    trade_size_threshold_asv: int
    buy_share_of_sell: float
    sell_share_of_buy: float
    cooldown_secs: int = 20
    console: Optional[Console] = None

    def __post_init__(self): self._last_trade_ts = 0.0
    def can_trade(self) -> bool: return (time.time() - self._last_trade_ts) >= self.cooldown_secs
    def mark_traded(self): self._last_trade_ts = time.time()

    def on_trade(self, tr) -> Optional[TradeSignal]:
        if tr.size_asv_units < self.trade_size_threshold_asv: return None
        if not self.can_trade(): return None
        if tr.side == "sell_asv":
            if self.console: self.console.log(f"[green]Big ASV SELL[/green] size={tr.size_asv_units} -> BUY portion")
            return TradeSignal(side="buy", ref_trade_size_asv=tr.size_asv_units)
        if tr.side == "buy_asv":
            if self.console: self.console.log(f"[yellow]Big ASV BUY[/yellow] size={tr.size_asv_units} -> SELL small portion")
            return TradeSignal(side="sell", ref_trade_size_asv=tr.size_asv_units)
        return None
