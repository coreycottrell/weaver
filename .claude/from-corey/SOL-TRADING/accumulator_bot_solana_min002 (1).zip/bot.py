import asyncio, os, signal, time
import yaml
from dotenv import load_dotenv
from rich.console import Console
from strategy.accumulator import AccumulatorByFlow
from risk.inventory import Inventory
from data.trade_feed import BirdeyeTradeFeed, SimulatedTradeFeed
from execution.jupiter_exec import JupiterExec
from solana_client import SolanaCtx

console = Console()

def load_config(path: str = "config.yaml") -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

async def main():
    load_dotenv()
    cfg = load_config()
    live_trading = os.getenv("LIVE_TRADING", "0") == "1"
    rpc_url = os.getenv("SOLANA_RPC_URL", "").strip()
    ws_url = os.getenv("SOLANA_WS_URL", "").strip() or None
    wallet_path = os.getenv("WALLET_PATH", "").strip() or None
    wallet_b58 = os.getenv("WALLET_BASE58", "").strip() or None
    jup_base = os.getenv("JUPITER_BASE_URL", "https://quote-api.jup.ag").rstrip("/")
    birdeye_key = os.getenv("BIRDEYE_API_KEY", "").strip() or None

    sol = await SolanaCtx.create(rpc_url=rpc_url if live_trading else (rpc_url or "https://api.mainnet-beta.solana.com"),
                                 ws_url=ws_url, wallet_path=wallet_path, wallet_base58=wallet_b58,
                                 require_wallet=live_trading, console=console)
    await sol.ensure_mint_info(cfg["SOL_MINT"]); await sol.ensure_mint_info(cfg["ASV_MINT"])
    sol.cfg["SOL_MINT"] = cfg["SOL_MINT"]; sol.cfg["ASV_MINT"] = cfg["ASV_MINT"]

    inv = Inventory(asv_mint=cfg["ASV_MINT"], sol_mint=cfg["SOL_MINT"],
                    max_asv_position=int(cfg["max_asv_position"]),
                    max_daily_sol_spend=float(cfg["max_daily_sol_spend"]),
                    dca_asv_per_day=int(cfg["dca_asv_per_day"]), console=console)

    strat = AccumulatorByFlow(trade_size_threshold_asv=int(cfg["trade_size_threshold_asv"]),
                              buy_share_of_sell=float(cfg["buy_share_of_sell"]),
                              sell_share_of_buy=float(cfg["sell_share_of_buy"]),
                              cooldown_secs=int(cfg["cooldown_secs"]), console=console)

    execu = JupiterExec(sol_ctx=sol, jupiter_base=jup_base, slippage_bps=int(cfg["slippage_bps"]),
                        priority_fee_lamports=int(cfg["priority_fee_lamports"]),
                        min_notional_sol=float(cfg["min_notional_sol"]), live=live_trading, console=console,
                        dynamic_floor_cfg={"floor_usd_base": float(cfg["floor_usd_base"]),
                                           "floor_usd_daily_increment": float(cfg["floor_usd_daily_increment"]),
                                           "floor_start_date_utc": cfg["floor_start_date_utc"]},
                        smallest_trade_cfg={"min_trade_sol": float(cfg["min_trade_sol"]),
                                            "min_trade_asv_units": int(cfg["min_trade_asv_units"]),
                                            "enable_dynamic_min_trade": bool(cfg["enable_dynamic_min_trade"]),
                                            "fee_multiple_for_min_trade": int(cfg["fee_multiple_for_min_trade"])})

    feed = BirdeyeTradeFeed(api_key=birdeye_key, asv_mint=cfg["ASV_MINT"], sol_mint=cfg["SOL_MINT"], console=console) if birdeye_key else            SimulatedTradeFeed(asv_mint=cfg["ASV_MINT"], sol_mint=cfg["SOL_MINT"],
                              baseline_price_sol=float(cfg["simulated_baseline_price_sol"]),
                              noise_pct=float(cfg["sim_noise_pct"]), console=console)

    console.rule("[bold]SOL/ASV Accumulator[/bold]")
    console.print(f"Live: {live_trading}  Jupiter: {jup_base}  Feed: {feed.name()}")
    console.print("Paper ledger unless LIVE_TRADING=1 and wallet configured.\n")

    poll_interval = int(cfg["poll_interval_secs"])
    stop = asyncio.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try: asyncio.get_event_loop().add_signal_handler(sig, stop.set)
        except NotImplementedError: pass

    last_heartbeat = 0.0
    while not stop.is_set():
        try: trades = await feed.fetch_trades()
        except Exception as e:
            console.log(f"[red]Feed error[/red]: {e}"); trades = []

        for tr in trades:
            action = strat.on_trade(tr)
            if action is None: continue
            if action.side == "buy":
                target_asv = inv.size_buy_asv(trade_asv_size=action.ref_trade_size_asv, share=strat.buy_share_of_sell)
                if target_asv <= 0: continue
                txsig, filled_asv, spent_sol = await execu.buy_exact_asv_output(asv_out_units=target_asv)
                inv.on_buy_filled(asv_units=filled_asv, sol_spent=spent_sol)
            elif action.side == "sell":
                target_asv = inv.size_sell_asv(trade_asv_size=action.ref_trade_size_asv, share=strat.sell_share_of_buy)
                if target_asv <= 0: continue
                txsig, sold_asv, recv_sol = await execu.sell_exact_asv_input(asv_in_units=target_asv)
                if sold_asv > 0: inv.on_sell_filled(asv_units=sold_asv, sol_received=recv_sol)
            strat.mark_traded()

        now = time.time()
        if now - last_heartbeat > 30: console.print(inv.status_line(sol)); last_heartbeat = now
        await asyncio.sleep(poll_interval)

    console.rule("[bold red]Shutting down[/bold red]")
    console.print(inv.summary_table())

if __name__ == "__main__":
    try: asyncio.run(main())
    except KeyboardInterrupt: pass
