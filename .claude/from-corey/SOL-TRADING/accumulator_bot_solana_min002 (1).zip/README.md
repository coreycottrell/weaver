# See bot description in the chat; dynamic USD floor and smallest trade controls implemented.
