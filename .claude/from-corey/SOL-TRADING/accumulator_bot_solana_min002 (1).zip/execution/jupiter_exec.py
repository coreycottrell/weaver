from typing import Optional, Tuple
import aiohttp, datetime
from rich.console import Console
from solana_client import SolanaCtx

class JupiterExec:
    def __init__(self, sol_ctx: SolanaCtx, jupiter_base: str, slippage_bps: int, priority_fee_lamports: int, min_notional_sol: float, live: bool, console: Optional[Console] = None, dynamic_floor_cfg=None, smallest_trade_cfg=None):
        self.sol = sol_ctx; self.base = jupiter_base; self.slippage_bps = slippage_bps
        self.priority_fee_lamports = priority_fee_lamports; self.min_notional_sol = min_notional_sol
        self.live = live; self.console = console
        self.dynamic_floor_cfg = dynamic_floor_cfg or {}; self.smallest_trade_cfg = smallest_trade_cfg or {}

    async def _quote(self, input_mint: str, output_mint: str, amount: int, mode: str):
        url = f"{self.base}/v6/quote"; params = {"inputMint": input_mint, "outputMint": output_mint, "amount": str(amount), "slippageBps": str(self.slippage_bps), "swapMode": mode, "platformFeeBps": "0"}
        async with aiohttp.ClientSession() as ses:
            async with ses.get(url, params=params, timeout=15) as resp:
                if resp.status != 200: raise RuntimeError(f"Jupiter quote {resp.status}: {await resp.text()}")
                return await resp.json()

    async def _swap_instructions(self, route, user_public_key: str):
        url = f"{self.base}/v6/swap-instructions"
        payload = {"quoteResponse": route, "userPublicKey": user_public_key, "wrapAndUnwrapSol": True, "dynamicComputeUnitLimit": True, "prioritizationFeeLamports": self.priority_fee_lamports}
        async with aiohttp.ClientSession() as ses:
            async with ses.post(url, json=payload, timeout=20) as resp:
                if resp.status != 200: raise RuntimeError(f"Jupiter swap-instructions {resp.status}: {await resp.text()}")
                return await resp.json()

    async def _sol_usd_price(self) -> float:
        sol_dec = self.sol.get_mint_decimals_cached(self.sol.cfg["SOL_MINT"])
        usdc_mint = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
        amount_sol_atomic = 1 * (10 ** sol_dec)
        route = await self._quote(self.sol.cfg["SOL_MINT"], usdc_mint, amount_sol_atomic, "ExactIn")
        out_usdc = float(route["data"][0]["outAmount"]) / 1_000_000.0
        return max(out_usdc, 1e-9)

    def _days_since(self, date_str: str) -> int:
        start = datetime.datetime.strptime(date_str, "%Y-%m-%d").date(); today = datetime.date.today()
        return max((today - start).days, 0)

    async def _dynamic_floor_sol(self) -> float:
        base = float(self.dynamic_floor_cfg.get("floor_usd_base", 0.0))
        inc = float(self.dynamic_floor_cfg.get("floor_usd_daily_increment", 0.0))
        start = self.dynamic_floor_cfg.get("floor_start_date_utc", "2025-01-01")
        days = self._days_since(start)
        floor_usd = base + inc * days
        sol_usd = await self._sol_usd_price()
        floor_sol = floor_usd / sol_usd
        if self.console: self.console.log(f"[blue]Dynamic floor[/blue]: USD={floor_usd:.6f}  SOL={floor_sol:.10f} (SOL/USD={sol_usd:.2f})")
        return floor_sol

    async def _enforce_min_trade(self, expected_notional_sol: float, asv_units: int) -> bool:
        min_trade_sol = float(self.smallest_trade_cfg.get("min_trade_sol", 0.0))
        min_trade_units = int(self.smallest_trade_cfg.get("min_trade_asv_units", 0))
        if expected_notional_sol < max(min_trade_sol, self.min_notional_sol):
            if self.console: self.console.log(f"[red]Skip trade[/red] notional {expected_notional_sol:.6f} SOL < min {max(min_trade_sol, self.min_notional_sol):.6f} SOL")
            return False
        if asv_units < min_trade_units:
            if self.console: self.console.log(f"[red]Skip trade[/red] ASV units {asv_units} < min {min_trade_units}")
            return False
        if self.smallest_trade_cfg.get("enable_dynamic_min_trade", False):
            base_fee_sol = 5000 / 1_000_000_000
            priority_fee_sol = self.priority_fee_lamports / 1_000_000_000
            est_fee = base_fee_sol + priority_fee_sol
            mult = int(self.smallest_trade_cfg.get("fee_multiple_for_min_trade", 200))
            if expected_notional_sol < est_fee * mult:
                if self.console: self.console.log(f"[red]Skip trade[/red] notional {expected_notional_sol:.6f} SOL < {mult}× fee ({est_fee*mult:.6f} SOL)")
                return False
        return True

    async def buy_exact_asv_output(self, asv_out_units: int) -> Tuple[str, int, float]:
        sol_dec = self.sol.get_mint_decimals_cached(self.sol.cfg["SOL_MINT"])
        amount_atomic = asv_out_units
        route = await self._quote(self.sol.cfg["SOL_MINT"], self.sol.cfg["ASV_MINT"], amount_atomic, "ExactOut")
        in_sol = float(route["data"][0]["inAmount"]) / (10 ** sol_dec)
        if not await self._enforce_min_trade(in_sol, asv_out_units): return ("SKIPPED_MIN", 0, 0.0)
        if not self.live: return ("PAPER", asv_out_units, in_sol)
        ixn = await self._swap_instructions(route, self.sol.pubkey_base58())
        txsig = await self.sol.execute_swap_instructions(ixn); return (txsig, asv_out_units, in_sol)

    async def sell_exact_asv_input(self, asv_in_units: int) -> Tuple[str, int, float]:
        asv_dec = self.sol.get_mint_decimals_cached(self.sol.cfg["ASV_MINT"]); sol_dec = self.sol.get_mint_decimals_cached(self.sol.cfg["SOL_MINT"])
        amount_atomic = asv_in_units
        route = await self._quote(self.sol.cfg["ASV_MINT"], self.sol.cfg["SOL_MINT"], amount_atomic, "ExactIn")
        out_sol = float(route["data"][0]["outAmount"]) / (10 ** sol_dec)
        floor_sol = await self._dynamic_floor_sol()
        asv_tokens = asv_in_units / (10 ** asv_dec)
        implied_price = out_sol / max(asv_tokens, 1e-12)
        if implied_price < floor_sol:
            if self.console: self.console.log(f"[blue]Skip SELL[/blue] floor: implied {implied_price:.10f} < floor {floor_sol:.10f}")
            return ("SKIPPED_FLOOR", 0, 0.0)
        if not await self._enforce_min_trade(out_sol, asv_in_units): return ("SKIPPED_MIN", 0, 0.0)
        if not self.live: return ("PAPER", asv_in_units, out_sol)
        ixn = await self._swap_instructions(route, self.sol.pubkey_base58())
        txsig = await self.sol.execute_swap_instructions(ixn); return (txsig, asv_in_units, out_sol)
