import time, random
from dataclasses import dataclass
from typing import List, Optional
import aiohttp
from rich.console import Console

@dataclass
class Trade:
    ts: float
    side: str          # 'sell_asv' or 'buy_asv'
    size_asv_units: int

class TradeFeed:
    def name(self) -> str: return "abstract"
    async def fetch_trades(self) -> List[Trade]: raise NotImplementedError

class BirdeyeTradeFeed(TradeFeed):
    def __init__(self, api_key: str, asv_mint: str, sol_mint: str, console: Optional[Console] = None):
        self.api_key = api_key; self.asv_mint = asv_mint; self.sol_mint = sol_mint; self.console = console

    def name(self) -> str: return "birdeye"

    async def fetch_trades(self) -> List[Trade]:
        url = "https://public-api.birdeye.so/defi/txs/token"
        headers = {"X-API-KEY": self.api_key, "accept": "application/json"}
        params = {"address": self.asv_mint, "offset": 0, "limit": 30}
        out: List[Trade] = []
        async with aiohttp.ClientSession() as ses:
            async with ses.get(url, headers=headers, params=params, timeout=10) as resp:
                if resp.status != 200: raise RuntimeError(f"Birdeye status {resp.status}: {await resp.text()}")
                data = await resp.json()
        items = data.get("data", {}).get("items", [])
        for it in items:
            token_in = it.get("tokenIn", {}); token_out = it.get("tokenOut", {})
            mint_in = token_in.get("address"); mint_out = token_out.get("address")
            amount_in = token_in.get("uiAmount", 0.0); amount_out = token_out.get("uiAmount", 0.0)
            side = None; size_ui = 0.0
            if mint_in == self.asv_mint: side = "sell_asv"; size_ui = float(amount_in or 0.0)
            elif mint_out == self.asv_mint: side = "buy_asv"; size_ui = float(amount_out or 0.0)
            else: continue
            size_units = int(size_ui * 1_000_000); out.append(Trade(ts=time.time(), side=side, size_asv_units=size_units))
        return out

class SimulatedTradeFeed(TradeFeed):
    def __init__(self, asv_mint: str, sol_mint: str, baseline_price_sol: float, noise_pct: float = 0.05, console: Optional[Console] = None):
        self.asv_mint = asv_mint; self.sol_mint = sol_mint; self.price_sol = baseline_price_sol; self.noise_pct = noise_pct; self.console = console
    def name(self) -> str: return "sim"
    async def fetch_trades(self) -> List[Trade]:
        trades: List[Trade] = []; burst = random.randint(1, 3)
        for _ in range(burst):
            self.price_sol *= (1.0 + random.uniform(-self.noise_pct, self.noise_pct))
            size_ui = max(1000.0, random.lognormvariate(9.0, 0.6) / 1e6)
            size_units = int(size_ui * 1_000_000)
            side = "sell_asv" if random.random() < 0.5 else "buy_asv"
            trades.append(Trade(ts=time.time(), side=side, size_asv_units=size_units))
        return trades
