import json, base58
from dataclasses import dataclass
from typing import Optional, Dict, Any
from rich.console import Console
from solana.rpc.async_api import AsyncClient
from solana.rpc.types import TxOpts
from solana.keypair import Keypair
from solana.publickey import PublicKey
from solana.rpc.commitment import Confirmed
from solders.transaction import VersionedTransaction as SoldersVersionedTransaction

@dataclass
class SolanaCtx:
    rpc: AsyncClient
    wallet: Optional[Keypair]
    ws_url: Optional[str]
    cfg: Dict[str, Any]
    console: Optional[Console] = None

    @classmethod
    async def create(cls, rpc_url: str, ws_url: Optional[str], wallet_path: Optional[str], wallet_base58: Optional[str], require_wallet: bool, console: Optional[Console] = None):
        client = AsyncClient(rpc_url, commitment=Confirmed)
        wallet = None
        if wallet_path:
            with open(wallet_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list): wallet = Keypair.from_secret_key(bytes(data))
            else: raise ValueError("Wallet file is not a list of ints")
        elif wallet_base58:
            secret = base58.b58decode(wallet_base58); wallet = Keypair.from_secret_key(secret)
        elif require_wallet: raise ValueError("Live mode requires a wallet")
        ctx = cls(rpc=client, wallet=wallet, ws_url=ws_url, cfg={}, console=console); return ctx

    def pubkey_base58(self) -> str: return str(self.wallet.public_key) if self.wallet else ""

    async def ensure_mint_info(self, mint: str):
        resp = await self.rpc.get_account_info(PublicKey(mint))
        if resp.value is None: raise RuntimeError(f"Mint {mint} not found on chain")
        data = resp.value.data
        if hasattr(data, "parsed"): dec = data.parsed["info"]["decimals"]
        else:
            import base64; raw = base64.b64decode(data[0]); dec = raw[44]
        if "mints" not in self.cfg: self.cfg["mints"] = {}
        self.cfg["mints"][mint] = {"decimals": int(dec)}

    def get_mint_decimals_cached(self, mint: str) -> int: return int(self.cfg["mints"][mint]["decimals"])

    async def execute_swap_instructions(self, ixn_resp: dict) -> str:
        if self.wallet is None: raise RuntimeError("No wallet for live trading")
        swap_tx_b64 = ixn_resp.get("swapTransaction")
        if not swap_tx_b64: raise RuntimeError("No swapTransaction in response")
        import base64 as b64; raw = b64.b64decode(swap_tx_b64)
        vtx = SoldersVersionedTransaction.from_bytes(raw)
        from solders.keypair import Keypair as SKeypair; sk = SKeypair.from_bytes(bytes(self.wallet.secret_key))
        vtx = vtx.sign([sk])
        sig = await self.rpc.send_raw_transaction(bytes(vtx), opts=TxOpts(skip_preflight=True, max_retries=3))
        await self.rpc.confirm_transaction(sig.value)
        if self.console: self.console.log(f"[bold cyan]Sent tx[/bold cyan] {str(sig.value)}")
        return str(sig.value)
