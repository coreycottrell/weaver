#!/usr/bin/env python3
"""
announce_new_messages.py
- Parses changed message files in the latest push
- Groups by room
- Ensures a per-room Issue exists titled "Room: <room-id>"
- Posts a comment summarizing new messages
- Updates rooms/<room>/index.json append-only manifest
"""
import os, json, subprocess, pathlib, datetime as dt, textwrap, sys, time, urllib.request

REPO = os.environ.get("GITHUB_REPOSITORY", "")
TOKEN = os.environ.get("GITHUB_TOKEN", os.environ.get("GH_TOKEN", ""))  # GITHUB_TOKEN is provided by Actions
API = f"https://api.github.com/repos/{REPO}" if REPO else ""

def run(cmd, cwd=None):
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"cmd failed: {' '.join(cmd)}\n{p.stdout}\n{p.stderr}")
    return p.stdout.strip()

def changed_files():
    sha = os.environ.get("GITHUB_SHA")
    if not sha:
        # fallback: compare last two commits
        sha = run(["git", "rev-parse", "HEAD"])
        prev = run(["git", "rev-parse", "HEAD~1"])
        diff = run(["git", "diff", "--name-only", prev, sha])
    else:
        diff = run(["git", "diff-tree", "--no-commit-id", "--name-only", "-r", sha])
    files = [f for f in diff.splitlines() if f.startswith("rooms/") and "/messages/" in f and f.endswith(".json")]
    return files

def ensure_room_issue(room_id):
    # search issues by title (open), create if not exists
    q = f"{API}/issues?state=open&per_page=100"
    req = urllib.request.Request(q, headers={"Authorization": f"token {TOKEN}", "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req) as r:
        issues = json.load(r)
    for iss in issues:
        if iss.get("title") == f"Room: {room_id}":
            return iss["number"]
    # create
    body = f"This issue tracks activity for room **{room_id}**. Subscribe to receive notifications on new messages."
    data = json.dumps({"title": f"Room: {room_id}", "body": body}).encode("utf-8")
    req = urllib.request.Request(f"{API}/issues", data=data, headers={"Authorization": f"token {TOKEN}", "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req) as r:
        created = json.load(r)
    return created["number"]

def post_comment(issue_number, body):
    data = json.dumps({"body": body}).encode("utf-8")
    req = urllib.request.Request(f"{API}/issues/{issue_number}/comments", data=data, headers={"Authorization": f"token {TOKEN}", "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req) as r:
        json.load(r)

def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def update_index(room_path, messages):
    idx_path = pathlib.Path(room_path) / "index.json"
    # load existing
    index = {"version": "1.0", "updated": dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"), "messages": []}
    if idx_path.exists():
        try:
            index = load_json(idx_path)
        except Exception:
            pass
    # append new (avoid duplicates by id)
    have = {m["id"] for m in index.get("messages", [])}
    for m in messages:
        if m["id"] not in have:
            index["messages"].append({"id": m["id"], "ts": m["ts"], "summary": m.get("summary",""), "path": m["_path"]})
    index["messages"].sort(key=lambda x: x["ts"])
    # write
    tmp = idx_path.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(index, f, indent=2)
        f.write("\n")
    os.replace(tmp, idx_path)

def commit_index_changes():
    # commit with [skip ci] to avoid retrigger
    status = run(["git", "status", "--porcelain"])
    if not status:
        return
    run(["git", "add", "-A"])
    run(["git", "config", "user.name", "comms-bot"])
    run(["git", "config", "user.email", "comms-bot@users.noreply.github.com"])
    run(["git", "commit", "-m", "chore: update room indexes [skip ci]"])
    # try push, allow a single retry in case of race
    for i in range(2):
        try:
            run(["git", "pull", "--rebase", "origin", "HEAD"])
            run(["git", "push", "origin", "HEAD"])
            return
        except Exception as e:
            if i == 1:
                raise

def main():
    files = changed_files()
    if not files:
        print("No relevant message files changed.")
        return
    by_room = {}
    for path in files:
        # path like rooms/<room>/messages/YYYY/MM/file.json
        parts = pathlib.PurePosixPath(path).parts
        room_id = parts[1]
        msg = load_json(pathlib.Path(path))
        msg["_path"] = path
        by_room.setdefault(room_id, []).append(msg)

    # Announce + update index per room
    for room, msgs in by_room.items():
        msgs.sort(key=lambda m: m["ts"])
        issue_num = ensure_room_issue(room)
        # Build comment
        lines = [f"**{len(msgs)} new message(s) in `{room}`**"]
        for m in msgs:
            lines.append(f"- `{m['ts']}` **{m['author']['id']}** · *{m['type']}* · **{m['summary']}**  \n  ↪️ `{m['_path']}`")
        post_comment(issue_num, "\n".join(lines))
        # Update index
        room_path = pathlib.Path("rooms") / room
        update_index(room_path, msgs)

    commit_index_changes()

if __name__ == "__main__":
    main()
