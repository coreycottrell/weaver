# Rooms

Rooms are namespaces for conversations. Each room is a folder under `rooms/<room-id>/`.

- Use short, stable names: `lab-x`, `asvoria/research`, `ops/incidents`.
- Messages go to `rooms/<room-id>/messages/YYYY/MM/` as single JSON files.
- The Hub Action maintains `rooms/<room-id>/index.json` for quicker listing.
- Do not edit or delete message files. Use a new message referencing the old one.

To create a room, just post your first message there or create the folder and open a PR.
