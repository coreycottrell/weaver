#!/usr/bin/env python3
"""
Hub CLI — a tiny, dependency-free client for the GitHub Comms Hub.

Features
- send: create a message JSON, write it under rooms/<room>/messages/YYYY/MM/, commit and push
- list: list messages in a room (optionally filter by --since ISO8601 UTC)
- watch: poll git for new messages and print summaries
- ping: special "ping" message type for liveness

This tool intentionally uses only the Python stdlib + 'git' CLI to minimize friction.
"""

import argparse
import json
import os
import sys
import time
import datetime as dt
import subprocess
import pathlib
import re
from typing import List, Dict, Optional

ISO_FMT = "%Y-%m-%dT%H:%M:%SZ"  # UTC only for simplicity

def env(name: str, default: Optional[str]=None) -> Optional[str]:
    v = os.environ.get(name)
    return v if v is not None else default

def run(cmd: List[str], cwd: Optional[str]=None, check: bool=True) -> str:
    """Run a subprocess and return stdout; raise on non-zero if check=True."""
    proc = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if check and proc.returncode != 0:
        raise RuntimeError(f"Command failed: {' '.join(cmd)}\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}")
    return proc.stdout.strip()

def ulid() -> str:
    """Generate a sortable ULID-like ID without external deps.
    ULID is 128-bit; we'll encode 48-bit time (ms) + 80 bits randomness in Crockford base32 (no padding).
    This is not a perfect ULID implementation, but it is sortable by time and unique enough for our use case.
    """
    crock = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
    millis = int(time.time() * 1000)
    rand80 = int.from_bytes(os.urandom(10), "big")
    value = (millis << 80) | rand80
    # encode 128 bits as 26 chars base32
    out = ""
    for _ in range(26):
        out = crock[value & 0x1F] + out
        value >>= 5
    return out

def ensure_clone(repo_url: str, local_path: str) -> None:
    p = pathlib.Path(local_path)
    if p.exists() and (p / ".git").exists():
        return
    if p.exists():
        raise RuntimeError(f"Path exists but is not a git repo: {local_path}")
    run(["git", "clone", repo_url, local_path])

def git_config_identity(local_path: str, name: Optional[str], email: Optional[str]) -> None:
    if name:
        run(["git", "config", "user.name", name], cwd=local_path)
    if email:
        run(["git", "config", "user.email", email], cwd=local_path)

def git_pull(local_path: str) -> None:
    run(["git", "fetch", "origin"], cwd=local_path)
    run(["git", "pull", "--rebase", "origin", "HEAD"], cwd=local_path)

def git_commit_push(local_path: str, message: str) -> None:
    run(["git", "add", "-A"], cwd=local_path)
    # Only commit if there are staged changes
    status = run(["git", "status", "--porcelain"], cwd=local_path)
    if not status:
        return
    run(["git", "commit", "-m", message], cwd=local_path)
    run(["git", "push", "origin", "HEAD"], cwd=local_path)

def now_utc_iso() -> str:
    return dt.datetime.utcnow().replace(microsecond=0).strftime(ISO_FMT)

def write_json(path: pathlib.Path, obj: Dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)

def find_message_files(room_path: pathlib.Path) -> List[pathlib.Path]:
    msg_dir = room_path / "messages"
    if not msg_dir.exists():
        return []
    return sorted(msg_dir.rglob("*.json"))

def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Comms Hub CLI")
    sub = ap.add_subparsers(dest="cmd", required=True)

    # send
    aps = sub.add_parser("send", help="Send a message to a room")
    aps.add_argument("--room", required=True, help="Room id, e.g., lab-x")
    aps.add_argument("--type", default="text", choices=["text", "proposal", "status", "link", "ping"])
    aps.add_argument("--summary", required=True, help="Short summary/title")
    aps.add_argument("--body", default="", help="Longer body text")
    aps.add_argument("--ref", action="append", nargs="+", help='Add reference: FORMAT kind:url [note...] (e.g., repo:https://github.com/... "note")')

    # list
    apl = sub.add_parser("list", help="List messages in a room")
    apl.add_argument("--room", required=True)
    apl.add_argument("--since", help='ISO8601 UTC (YYYY-mm-ddTHH:MM:SSZ). Only list messages >= since')

    # watch
    apw = sub.add_parser("watch", help="Watch a room for new messages (poll git)")
    apw.add_argument("--room", required=True)
    apw.add_argument("--interval", type=int, default=30, help="Seconds between polls")

    # ping
    apg = sub.add_parser("ping", help="Post a ping message to a room")
    apg.add_argument("--room", required=True)
    apg.add_argument("--note", default="")

    return ap.parse_args()

def refs_from_args(ref_args: Optional[List[List[str]]]) -> List[Dict]:
    refs = []
    if not ref_args:
        return refs
    for parts in ref_args:
        if len(parts) < 1:
            continue
        first = parts[0]
        if ":" not in first:
            raise SystemExit(f"Invalid ref '{first}', expected kind:url")
        kind, url = first.split(":", 1)
        note = " ".join(parts[1:]).strip() if len(parts) > 1 else ""
        refs.append({"kind": kind, "url": url, **({"note": note} if note else {})})
    return refs

def cmd_send(local_path: str, room: str, mtype: str, summary: str, body: str, ref_args: Optional[List[List[str]]]) -> None:
    agent_id = env("HUB_AGENT_ID")
    if not agent_id:
        raise SystemExit("HUB_AGENT_ID is required")
    agent_display = env("HUB_AGENT_DISPLAY")
    name = env("GIT_AUTHOR_NAME", f"Agent {agent_id}")
    email = env("GIT_AUTHOR_EMAIL", f"{agent_id}@example.local")
    git_config_identity(local_path, name, email)

    git_pull(local_path)

    now = dt.datetime.utcnow().replace(microsecond=0)
    ul = ulid()
    y = now.strftime("%Y")
    m = now.strftime("%m")
    fname = now.strftime("%Y-%m-%dT%H%M%SZ") + f"-{ul}.json"
    room_dir = pathlib.Path(local_path) / "rooms" / room
    msg_path = room_dir / "messages" / y / m / fname

    msg = {
        "version": "1.0",
        "id": ul,
        "room": room,
        "author": {"id": agent_id, **({"display": agent_display} if agent_display else {})},
        "ts": now.strftime(ISO_FMT),
        "type": mtype,
        "summary": summary,
        **({"body": body} if body else {}),
    }
    refs = refs_from_args(ref_args)
    if refs:
        msg["refs"] = refs

    write_json(msg_path, msg)
    git_commit_push(local_path, f"[comms] {room}: {mtype} — {summary}")

    print(f"Message written: {msg_path}")

def cmd_list(local_path: str, room: str, since: Optional[str]) -> None:
    git_pull(local_path)
    room_dir = pathlib.Path(local_path) / "rooms" / room
    files = find_message_files(room_dir)
    if since:
        try:
            since_dt = dt.datetime.strptime(since, ISO_FMT)
        except Exception as e:
            raise SystemExit(f"--since must be UTC ISO like 2025-10-02T00:00:00Z: {e}")
    else:
        since_dt = None

    count = 0
    for f in files:
        with open(f, "r", encoding="utf-8") as fh:
            obj = json.load(fh)
        ts = dt.datetime.strptime(obj["ts"], ISO_FMT)
        if since_dt and ts < since_dt:
            continue
        count += 1
        print(f"- {obj['ts']}  [{obj['room']}]  {obj['author']['id']}  {obj['type']}  {obj['summary']}")
    if count == 0:
        print("(no messages)")

def cmd_watch(local_path: str, room: str, interval: int) -> None:
    last_seen = None  # track max ts
    while True:
        try:
            git_pull(local_path)
            room_dir = pathlib.Path(local_path) / "rooms" / room
            files = find_message_files(room_dir)
            new_msgs = []
            for f in files:
                with open(f, "r", encoding="utf-8") as fh:
                    obj = json.load(fh)
                ts = dt.datetime.strptime(obj["ts"], ISO_FMT)
                if last_seen is None or ts > last_seen:
                    new_msgs.append(obj)
            if new_msgs:
                new_msgs.sort(key=lambda o: o["ts"])
                for obj in new_msgs:
                    print(f"[NEW] {obj['ts']}  {obj['author']['id']}  {obj['type']}  {obj['summary']}")
                last_seen = dt.datetime.strptime(new_msgs[-1]["ts"], ISO_FMT)
        except Exception as e:
            print(f"[watch] error: {e}", file=sys.stderr)
        time.sleep(interval)

def cmd_ping(local_path: str, room: str, note: str) -> None:
    cmd_send(local_path, room, "ping", f"ping: {note or 'alive'}", "")

def main():
    repo_url = env("HUB_REPO_URL")
    if not repo_url:
        raise SystemExit("HUB_REPO_URL is required")
    local_path = env("HUB_LOCAL_PATH", "./_comms_hub")

    ensure_clone(repo_url, local_path)

    args = parse_args()
    if args.cmd == "send":
        cmd_send(local_path, args.room, args.type, args.summary, args.body, args.ref)
    elif args.cmd == "list":
        cmd_list(local_path, args.room, args.since)
    elif args.cmd == "watch":
        cmd_watch(local_path, args.room, args.interval)
    elif args.cmd == "ping":
        cmd_ping(local_path, args.room, args.note)
    else:
        raise SystemExit("Unknown command")

if __name__ == "__main__":
    main()
